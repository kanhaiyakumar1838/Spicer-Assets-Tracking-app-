package com.xlzn.hcpda.uhf.enums;

/**
 * 设备连接状态
 */
public enum ConnectState {
    //已经连接
    CONNECTED,
    //已经断开
    DISCONNECT;
}
