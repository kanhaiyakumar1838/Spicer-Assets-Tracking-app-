package com.xlzn.hcpda.uhf.enums;

/**
 * 盘点模式
 */
public enum InventoryModeForPower {
    //快速模式
    FAST_MODE,
    //省电模式
    POWER_SAVING_MODE;
}
